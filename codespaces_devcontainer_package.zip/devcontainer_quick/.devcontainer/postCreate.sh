#!/usr/bin/env bash
set -euo pipefail
echo "Devcontainer ready"; echo "Run: docker compose -f observability/compose.yaml up -d"
